"use client";

import React, { useState, useEffect } from "react";
import Image from "next/image";
import { siteConfig, GalleryItem } from "@/data/site";
import {
  X,
  MapPin,
  ArrowRight,
  ArrowLeft,
  Maximize2,
  Filter,
  CheckCircle2,
  Phone,
  ShieldCheck,
  Sparkles,
} from "lucide-react";

interface GalleryScreenProps {
  onClose?: () => void;
  isModal?: boolean;
}

export default function GalleryScreen({ onClose, isModal = false }: GalleryScreenProps) {
  const [activeFilter, setActiveFilter] = useState<string>("all");
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  const filters = [
    { id: "all", label: "All Operations", count: siteConfig.gallery.length },
    {
      id: "crane",
      label: "Crane & Heavy Rigging",
      count: siteConfig.gallery.filter((i) => i.category === "crane").length,
    },
    {
      id: "emergency",
      label: "Emergency Disaster Relief",
      count: siteConfig.gallery.filter((i) => i.category === "emergency").length,
    },
    {
      id: "palms",
      label: "Palm Removal & Canopy",
      count: siteConfig.gallery.filter((i) => i.category === "palms").length,
    },
    {
      id: "stump",
      label: "Root & Lawn Care",
      count: siteConfig.gallery.filter((i) => i.category === "stump").length,
    },
  ];

  const filteredItems =
    activeFilter === "all"
      ? siteConfig.gallery
      : siteConfig.gallery.filter((item) => item.category === activeFilter);

  // Keyboard navigation for lightbox
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (lightboxIndex === null) {
        if (e.key === "Escape" && onClose) {
          onClose();
        }
        return;
      }

      if (e.key === "Escape") {
        setLightboxIndex(null);
      } else if (e.key === "ArrowRight") {
        setLightboxIndex((prev) =>
          prev !== null ? (prev + 1) % filteredItems.length : null
        );
      } else if (e.key === "ArrowLeft") {
        setLightboxIndex((prev) =>
          prev !== null
            ? (prev - 1 + filteredItems.length) % filteredItems.length
            : null
        );
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [lightboxIndex, filteredItems.length, onClose]);

  const activeItem =
    lightboxIndex !== null ? filteredItems[lightboxIndex] : null;

  return (
    <div className={`w-full ${isModal ? "min-h-full" : "min-h-screen"} bg-[#06160E] text-white flex flex-col`}>
      {/* Top Navigation Bar */}
      <header className="sticky top-0 z-40 bg-[#06160E]/95 backdrop-blur-xl border-b border-[#C5A880]/20 px-4 sm:px-8 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          {onClose && (
            <button
              onClick={onClose}
              aria-label="Back to page"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-[#DFCEB8] text-xs font-semibold transition-colors mr-2"
            >
              <ArrowLeft className="w-4 h-4" />
              <span className="hidden sm:inline">Back</span>
            </button>
          )}
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#C5A880] animate-pulse" />
              <span className="text-[10px] sm:text-xs font-bold uppercase tracking-[0.2em] text-[#C5A880]">
                Verified Field Operations
              </span>
            </div>
            <h1 className="font-serif text-lg sm:text-2xl font-bold text-white leading-tight">
              Palm Beach Job-Site Gallery
            </h1>
          </div>
        </div>

        <div className="flex items-center gap-2 sm:gap-3">
          <a
            href="#contact"
            onClick={() => {
              if (onClose) onClose();
            }}
            className="hidden md:inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-[#C5A880] hover:bg-[#DFCEB8] text-[#0A1E14] font-bold text-xs shadow-md transition-colors"
          >
            <span>Request Free Estimate</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </a>

          {onClose && (
            <button
              onClick={onClose}
              aria-label="Close Gallery Screen"
              className="p-2 sm:p-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white/80 hover:text-white transition-colors focus:outline-none"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
        {/* Intro & Filter Bar */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8 pb-6 border-b border-white/10">
          <div>
            <p className="text-xs sm:text-sm text-white/70 max-w-2xl leading-relaxed">
              Browse actual photographs of our 100-ton hydraulic crane lifts, Serco disaster relief grapple trucks, aerial boom trims, and precision root excavations across Palm Beach County estates.
            </p>
          </div>

          {/* Filter Pills */}
          <div className="flex flex-wrap gap-2 items-center">
            {filters.map((f) => {
              const active = activeFilter === f.id;
              return (
                <button
                  key={f.id}
                  onClick={() => {
                    setActiveFilter(f.id);
                    setLightboxIndex(null);
                  }}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 ${
                    active
                      ? "bg-[#C5A880] text-[#06160E] shadow-lg font-bold"
                      : "bg-white/5 text-white/80 hover:bg-white/10 hover:text-white border border-white/10"
                  }`}
                >
                  <span>{f.label}</span>
                  <span
                    className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                      active
                        ? "bg-[#06160E]/20 text-[#06160E]"
                        : "bg-white/10 text-white/60"
                    }`}
                  >
                    {f.count}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Gallery Photos Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map((item, index) => (
            <article
              key={item.id}
              onClick={() => setLightboxIndex(index)}
              className="group relative flex flex-col rounded-2xl bg-[#0E2A1D]/80 border border-[#C5A880]/20 overflow-hidden shadow-xl hover:border-[#C5A880]/60 hover:shadow-2xl hover:-translate-y-1 transition-all duration-300 cursor-pointer"
            >
              {/* Photo Viewport */}
              <div className="relative aspect-[4/3] w-full overflow-hidden bg-black/40">
                <Image
                  src={item.image}
                  alt={item.title}
                  fill
                  sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
                  className="object-cover object-center group-hover:scale-105 transition-transform duration-500"
                />

                {/* Top Floating Badges */}
                <div className="absolute top-3 left-3 right-3 flex items-center justify-between pointer-events-none">
                  <span className="px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider bg-[#06160E]/80 backdrop-blur-md text-[#DFCEB8] border border-[#C5A880]/30 shadow-md">
                    {item.categoryLabel}
                  </span>

                  <span className="w-8 h-8 rounded-lg bg-[#06160E]/70 backdrop-blur-md text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <Maximize2 className="w-4 h-4 text-[#C5A880]" />
                  </span>
                </div>

                {/* Bottom subtle gradient */}
                <div className="absolute inset-x-0 bottom-0 h-20 bg-gradient-to-t from-[#0E2A1D] via-[#0E2A1D]/50 to-transparent pointer-events-none" />
              </div>

              {/* Photo Meta & Caption */}
              <div className="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-1.5 text-[11px] text-[#C5A880] mb-2 font-medium">
                    <MapPin className="w-3.5 h-3.5 shrink-0" />
                    <span>{item.location}</span>
                  </div>

                  <h3 className="font-serif text-base font-bold text-white group-hover:text-[#DFCEB8] transition-colors leading-snug mb-2">
                    {item.title}
                  </h3>

                  <p className="text-xs text-white/70 line-clamp-2 leading-relaxed">
                    {item.description}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between text-[11px]">
                  <span className="text-[#C5A880] font-semibold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Job Completed</span>
                  </span>
                  <span className="text-white/50 group-hover:text-white transition-colors flex items-center gap-1 font-medium">
                    <span>View Photo</span>
                    <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
                  </span>
                </div>
              </div>
            </article>
          ))}
        </div>

        {/* Bottom Banner inside Gallery Screen */}
        <div className="mt-16 p-6 sm:p-8 rounded-2xl bg-gradient-to-r from-[#0E2A1D] to-[#163E2B] border border-[#C5A880]/30 flex flex-col sm:flex-row items-center justify-between gap-6 shadow-2xl">
          <div className="space-y-1 text-center sm:text-left">
            <h4 className="font-serif text-lg sm:text-xl font-bold text-white">
              Need Similar Crane or Tree Work on Your Estate?
            </h4>
            <p className="text-xs sm:text-sm text-white/75">
              Certified Arborists, 100-ton crane access, zero-lawn damage guarantee, and $5M liability coverage.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <a
              href="#contact"
              onClick={() => {
                if (onClose) onClose();
              }}
              className="px-6 py-3 rounded-xl bg-[#C5A880] hover:bg-[#DFCEB8] text-[#0A1E14] font-bold text-sm shadow-xl transition-all whitespace-nowrap"
            >
              Get Free Written Quote
            </a>
          </div>
        </div>
      </main>

      {/* Lightbox Modal (Zoomed View) */}
      {activeItem && lightboxIndex !== null && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-black/95 backdrop-blur-2xl flex flex-col items-center justify-between p-4 sm:p-6"
        >
          {/* Lightbox Header */}
          <div className="w-full max-w-5xl flex items-center justify-between py-2 border-b border-white/10">
            <div className="flex items-center gap-3 text-xs sm:text-sm text-white/70">
              <span className="font-mono text-[#C5A880] font-bold">
                {lightboxIndex + 1} / {filteredItems.length}
              </span>
              <span>•</span>
              <span className="text-white/90 font-medium truncate max-w-xs sm:max-w-md">
                {activeItem.title}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setLightboxIndex(null)}
                aria-label="Close Lightbox"
                className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Lightbox Center Image & Controls */}
          <div className="relative w-full max-w-5xl flex-1 my-4 flex items-center justify-center">
            {/* Previous Button */}
            <button
              onClick={() =>
                setLightboxIndex(
                  (lightboxIndex - 1 + filteredItems.length) %
                    filteredItems.length
                )
              }
              aria-label="Previous Photo"
              className="absolute left-2 sm:left-4 z-10 p-3 rounded-full bg-black/60 hover:bg-[#C5A880] text-white hover:text-[#06160E] border border-white/20 transition-all focus:outline-none"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>

            {/* Next Button */}
            <button
              onClick={() =>
                setLightboxIndex((lightboxIndex + 1) % filteredItems.length)
              }
              aria-label="Next Photo"
              className="absolute right-2 sm:right-4 z-10 p-3 rounded-full bg-black/60 hover:bg-[#C5A880] text-white hover:text-[#06160E] border border-white/20 transition-all focus:outline-none"
            >
              <ArrowRight className="w-5 h-5" />
            </button>

            {/* The Photo */}
            <div className="relative w-full h-full max-h-[70vh]">
              <Image
                src={activeItem.image}
                alt={activeItem.title}
                fill
                priority
                sizes="(max-width: 1280px) 100vw, 1280px"
                className="object-contain"
              />
            </div>
          </div>

          {/* Lightbox Bottom Caption */}
          <div className="w-full max-w-5xl bg-[#06160E]/90 border border-white/10 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-xs text-[#C5A880] font-semibold">
                <MapPin className="w-3.5 h-3.5" />
                <span>{activeItem.location}</span>
                <span>•</span>
                <span className="uppercase tracking-wider">
                  {activeItem.categoryLabel}
                </span>
              </div>
              <h2 className="font-serif text-base sm:text-lg font-bold text-white">
                {activeItem.title}
              </h2>
              <p className="text-xs text-white/75 max-w-2xl">
                {activeItem.description}
              </p>
            </div>

            <div className="flex items-center gap-3 shrink-0">
              <a
                href="#contact"
                onClick={() => {
                  setLightboxIndex(null);
                  if (onClose) onClose();
                }}
                className="px-5 py-2.5 rounded-xl bg-[#C5A880] hover:bg-[#DFCEB8] text-[#06160E] font-bold text-xs shadow-lg transition-colors flex items-center gap-2"
              >
                <span>Inquire About This Service</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
