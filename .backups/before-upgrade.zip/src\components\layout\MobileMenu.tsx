"use client";

import React, { useEffect, useState } from "react";
import Image from "next/image";
import { siteConfig } from "@/data/site";
import {
  Phone,
  X,
  ShieldCheck,
  ArrowRight,
  TreePine,
  ChevronDown,
  Sparkles,
  Award,
  MapPin,
} from "lucide-react";

interface MobileMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function MobileMenu({ isOpen, onClose }: MobileMenuProps) {
  const [servicesExpanded, setServicesExpanded] = useState(false);
  const [citiesExpanded, setCitiesExpanded] = useState(false);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        onClose();
      }
    };

    if (isOpen) {
      document.body.style.overflow = "hidden";
      window.addEventListener("keydown", handleKeyDown);
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Mobile Navigation Menu"
      className="fixed inset-0 z-[9999] lg:hidden flex justify-end"
    >
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/80 backdrop-blur-sm transition-opacity animate-fadeIn"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Slide Drawer */}
      <div className="relative w-full max-w-md h-full bg-[#06160E] border-l border-[#C5A880]/30 flex flex-col z-10 shadow-2xl overflow-hidden animate-slideInRight">
        {/* Drawer Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/10 bg-[#0A1E14] shrink-0">
          <a
            href="#hero"
            onClick={onClose}
            className="flex items-center gap-3 focus:outline-none"
          >
            <div className="relative w-12 h-12 shrink-0 drop-shadow-md">
              <Image
                src={siteConfig.logo || "/images/logo.png"}
                alt="Palm Beach Tree Removal"
                fill
                sizes="48px"
                className="object-contain object-center"
              />
            </div>
            <div>
              <div className="font-serif text-white font-bold text-base leading-none">
                PALM BEACH
              </div>
              <div className="text-[10px] text-[#C5A880] tracking-[0.16em] uppercase font-semibold mt-1">
                Est. 1992 &bull; Arboriculture
              </div>
            </div>
          </a>

          <button
            onClick={onClose}
            aria-label="Close navigation menu"
            className="p-2 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Navigation List */}
        <div className="flex-1 overflow-y-auto px-5 py-6 space-y-6">
          {/* Emergency Alert Bar */}
          <div className="p-3.5 rounded-xl bg-[#0E2A1D] border border-[#C5A880]/30 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              <div>
                <div className="text-[10px] uppercase tracking-wider text-emerald-400 font-bold">
                  24/7 Emergency Dispatch
                </div>
                <div className="text-xs text-white/80 font-medium">
                  {siteConfig.phone ? `Direct Line: ${siteConfig.phone}` : "Online Dispatch Active"}
                </div>
              </div>
            </div>

            {siteConfig.phone ? (
              <a
                href={`tel:${siteConfig.phoneRaw}`}
                onClick={onClose}
                className="px-3 py-1.5 rounded-lg bg-[#C5A880] text-[#0A1E14] text-xs font-bold flex items-center gap-1 shadow-md hover:bg-[#DFCEB8] transition-colors shrink-0"
              >
                <Phone className="w-3 h-3 fill-current" />
                <span>Call</span>
              </a>
            ) : (
              <a
                href="#contact"
                onClick={onClose}
                className="px-3 py-1.5 rounded-lg bg-[#C5A880] text-[#0A1E14] text-xs font-bold flex items-center gap-1 shadow-md hover:bg-[#DFCEB8] transition-colors shrink-0"
              >
                <span>Request</span>
                <ArrowRight className="w-3 h-3" />
              </a>
            )}
          </div>

          {/* Links */}
          <nav className="flex flex-col space-y-1">
            {/* Services Accordion */}
            <div className="flex flex-col">
              <button
                type="button"
                onClick={() => setServicesExpanded(!servicesExpanded)}
                className="w-full px-3.5 py-3 rounded-xl text-base font-semibold text-white hover:bg-white/5 transition-all flex items-center justify-between"
              >
                <span>Services</span>
                <ChevronDown
                  className={`w-4 h-4 text-[#C5A880] transition-transform duration-200 ${
                    servicesExpanded ? "rotate-180" : ""
                  }`}
                />
              </button>

              {servicesExpanded && (
                <div className="ml-3 pl-3 border-l-2 border-[#C5A880]/30 py-1 space-y-1 animate-fadeIn">
                  {siteConfig.services.map((service) => (
                    <a
                      key={service.id}
                      href="/#services"
                      onClick={onClose}
                      className="block px-3 py-2 rounded-lg text-sm text-white/80 hover:text-[#DFCEB8] hover:bg-white/5 transition-colors"
                    >
                      <div className="font-medium text-white/95">
                        {service.title}
                      </div>
                      <div className="text-[10px] text-[#C5A880]">
                        {service.tag}
                      </div>
                    </a>
                  ))}
                </div>
              )}
            </div>

            <a
              href="/#gallery"
              onClick={onClose}
              className="px-3.5 py-3 rounded-xl text-base font-semibold text-white/90 hover:text-white hover:bg-white/5 transition-colors flex items-center justify-between"
            >
              <span>Gallery</span>
              <ArrowRight className="w-4 h-4 text-white/30" />
            </a>

            <a
              href="/#before-after"
              onClick={onClose}
              className="px-3.5 py-3 rounded-xl text-base font-semibold text-white/90 hover:text-white hover:bg-white/5 transition-colors flex items-center justify-between"
            >
              <span>Before &amp; After</span>
              <ArrowRight className="w-4 h-4 text-white/30" />
            </a>

            {/* Service Areas Accordion */}
            <div className="flex flex-col">
              <button
                type="button"
                onClick={() => setCitiesExpanded(!citiesExpanded)}
                className="w-full px-3.5 py-3 rounded-xl text-base font-semibold text-white hover:bg-white/5 transition-all flex items-center justify-between"
              >
                <span className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-[#C5A880]" />
                  <span>Service Areas (8 Cities)</span>
                </span>
                <ChevronDown
                  className={`w-4 h-4 text-[#C5A880] transition-transform duration-200 ${
                    citiesExpanded ? "rotate-180" : ""
                  }`}
                />
              </button>

              {citiesExpanded && (
                <div className="ml-3 pl-3 border-l-2 border-[#C5A880]/30 py-1 space-y-1 animate-fadeIn">
                  {siteConfig.serviceAreas.map((city) => (
                    <a
                      key={city}
                      href="/#service-areas"
                      onClick={onClose}
                      className="block px-3 py-2 rounded-lg text-sm text-white/80 hover:text-[#DFCEB8] hover:bg-white/5 transition-colors"
                    >
                      {city}
                    </a>
                  ))}
                </div>
              )}
            </div>

            <a
              href="/#testimonials"
              onClick={onClose}
              className="px-3.5 py-3 rounded-xl text-base font-semibold text-white/90 hover:text-white hover:bg-white/5 transition-colors flex items-center justify-between"
            >
              <span>Client Reviews</span>
              <ArrowRight className="w-4 h-4 text-white/30" />
            </a>

            <a
              href="/#contact"
              onClick={onClose}
              className="px-3.5 py-3 rounded-xl text-base font-bold text-[#DFCEB8] hover:text-white hover:bg-white/5 transition-colors flex items-center justify-between"
            >
              <span>Contact Us</span>
              <ArrowRight className="w-4 h-4 text-[#C5A880]" />
            </a>

            <a
              href="/#faq"
              onClick={onClose}
              className="px-3.5 py-3 rounded-xl text-base font-semibold text-white/90 hover:text-white hover:bg-white/5 transition-colors flex items-center justify-between"
            >
              <span>Frequently Asked Questions</span>
              <ArrowRight className="w-4 h-4 text-white/30" />
            </a>
          </nav>

          {/* Action CTAs */}
          <div className="pt-4 border-t border-white/10 space-y-3">
            <a
              href="#contact"
              onClick={onClose}
              className="flex items-center justify-center gap-2 w-full py-3.5 px-4 rounded-xl bg-[#C5A880] hover:bg-[#DFCEB8] text-[#0A1E14] font-bold text-sm shadow-lg transition-colors"
            >
              <Sparkles className="w-4 h-4 text-[#0A1E14]" />
              <span>Get a Free Written Estimate</span>
            </a>

            {siteConfig.phone && (
              <a
                href={`tel:${siteConfig.phoneRaw}`}
                onClick={onClose}
                className="flex items-center justify-center gap-2 w-full py-3 px-4 rounded-xl bg-[#0E2A1D] border border-[#C5A880]/40 text-white font-bold text-sm hover:bg-[#163E2B] transition-colors"
              >
                <Phone className="w-4 h-4 text-[#C5A880] fill-current" />
                <span>Call Hotline {siteConfig.phone}</span>
              </a>
            )}
          </div>

          {/* Credentials Footer Strip */}
          <div className="pt-4 border-t border-white/10 grid grid-cols-2 gap-2 text-xs text-white/70">
            <div className="flex items-center gap-1.5 p-2 rounded-lg bg-white/5">
              <ShieldCheck className="w-4 h-4 text-[#C5A880] shrink-0" />
              <span>$5M Insurance</span>
            </div>
            <div className="flex items-center gap-1.5 p-2 rounded-lg bg-white/5">
              <Award className="w-4 h-4 text-[#C5A880] shrink-0" />
              <span>ISA Certified</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
