import type { Metadata } from "next";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import GalleryScreen from "@/components/sections/GalleryScreen";
import Chatbot from "@/components/chatbot/Chatbot";
import MobileActionBar from "@/components/layout/MobileActionBar";

export const metadata: Metadata = {
  title: "Field Operations Gallery | Palm Beach Tree Removal",
  description:
    "Explore authentic photographs from our Palm Beach tree removal operations: 100-ton crane lifts, Serco grapple disaster recovery, and precision estate arboriculture.",
};

export default function GalleryPage() {
  return (
    <>
      <Header />
      <div className="pt-24 sm:pt-28">
        <GalleryScreen isModal={false} />
      </div>
      <Footer />
      <Chatbot />
      <MobileActionBar />
    </>
  );
}
