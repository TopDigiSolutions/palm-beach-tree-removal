"use client";

import React, { useState, useEffect } from "react";
import Image from "next/image";
import { siteConfig } from "@/data/site";
import {
  Phone,
  Menu,
  TreePine,
  ShieldCheck,
  ChevronDown,
  ArrowRight,
  Sparkles,
  MapPin,
} from "lucide-react";
import MobileMenu from "./MobileMenu";

export default function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    let ticking = false;
    const handleScroll = () => {
      if (!ticking) {
        window.requestAnimationFrame(() => {
          const scrolled = window.scrollY > 20;
          setIsScrolled((prev) => (prev !== scrolled ? scrolled : prev));
          ticking = false;
        });
        ticking = true;
      }
    };
    handleScroll();
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled
            ? "bg-[#06160E]/95 backdrop-blur-xl shadow-[0_10px_30px_rgba(0,0,0,0.5)] border-b border-[#C5A880]/25 py-2"
            : "bg-[#06160E]/85 backdrop-blur-md border-b border-white/10 py-2.5"
        }`}
      >
        {/* Top Pre-Header Announcement Strip */}
        <div
          className={`transition-all duration-300 overflow-hidden ${
            isScrolled ? "max-h-0 opacity-0 mb-0 py-0" : "max-h-8 opacity-100 mb-1.5 pb-1.5 border-b border-white/10"
          }`}
        >
          <div className="container-custom flex items-center justify-between text-[10px] sm:text-xs text-white/80 px-3 sm:px-6">
            <div className="flex items-center gap-2 truncate">
              <span className="flex items-center gap-1 text-[#DFCEB8] font-medium shrink-0">
                <ShieldCheck className="w-3.5 h-3.5 text-[#C5A880]" />
                ISA Master Arborists
              </span>
              <span className="text-white/30">&bull;</span>
              <span className="text-white/70 truncate shrink-0">
                $5,000,000 Insurance
              </span>
              <span className="text-white/30 hidden md:inline">&bull;</span>
              <span className="hidden md:inline text-white/60">
                FL Lic. #CBC1264890
              </span>
            </div>

            <div className="flex items-center gap-1.5 shrink-0 ml-2">
              <Sparkles className="w-3 h-3 text-[#C5A880] animate-pulse" />
              {siteConfig.phone ? (
                <>
                  <span className="text-[10px] text-[#DFCEB8] font-bold uppercase tracking-wider hidden sm:inline">
                    ⚡ 24/7 Storm Response:
                  </span>
                  <a
                    href={`tel:${siteConfig.phoneRaw}`}
                    className="text-white hover:text-[#C5A880] font-bold tracking-wide transition-colors whitespace-nowrap bg-[#163E2B] px-2 py-0.5 rounded-full border border-[#C5A880]/30"
                  >
                    {siteConfig.phone}
                  </a>
                </>
              ) : (
                <a
                  href="#contact"
                  className="text-[#DFCEB8] hover:text-white font-bold text-[10px] tracking-wide transition-colors whitespace-nowrap bg-[#163E2B] px-2.5 py-0.5 rounded-full border border-[#C5A880]/30 flex items-center gap-1"
                >
                  <span>⚡ 24/7 Rapid Emergency Response</span>
                  <ArrowRight className="w-3 h-3 text-[#C5A880]" />
                </a>
              )}
            </div>
          </div>
        </div>

        {/* Main Navigation Bar */}
        <div className="container-custom flex items-center justify-between gap-2 sm:gap-4 px-3 sm:px-6">
          {/* Brand Logo & Heritage */}
          <a
            href="/"
            className="flex items-center gap-2.5 sm:gap-3 group shrink-0 focus-visible:outline-none"
            aria-label="Palm Beach Tree Removal Home"
          >
            <div className="relative w-11 h-11 sm:w-13 sm:h-13 group-hover:scale-105 transition-transform shrink-0 drop-shadow-md">
              <Image
                src={siteConfig.logo || "/images/logo.png"}
                alt="Palm Beach Tree Removal"
                fill
                sizes="52px"
                className="object-contain object-center"
                priority
              />
            </div>
            <div className="flex flex-col">
              <span className="font-serif text-white font-bold text-xs sm:text-base lg:text-lg tracking-wider leading-none group-hover:text-[#DFCEB8] transition-colors whitespace-nowrap">
                PALM BEACH
              </span>
              <span className="text-[8px] sm:text-[10px] text-[#C5A880] tracking-[0.14em] uppercase font-semibold mt-0.5 whitespace-nowrap">
                Tree Removal &bull; 1992
              </span>
            </div>
          </a>

          {/* Desktop Navigation Links */}
          <nav
            className="hidden lg:flex items-center gap-1 xl:gap-2 shrink-0"
            aria-label="Primary Navigation"
          >
            {/* Services Dropdown */}
            <div className="relative group/services">
              <button
                type="button"
                className="inline-flex items-center gap-1 px-2.5 xl:px-3 py-1.5 text-xs xl:text-sm font-medium text-white/90 hover:text-white rounded-lg transition-colors group-hover/services:text-[#DFCEB8] whitespace-nowrap"
              >
                <span>Services</span>
                <ChevronDown className="w-3.5 h-3.5 text-[#C5A880] transition-transform duration-200 group-hover/services:rotate-180" />
              </button>

              {/* Mega Dropdown Panel */}
              <div className="absolute top-full left-0 pt-2 w-72 opacity-0 -translate-y-2 pointer-events-none group-hover/services:opacity-100 group-hover/services:translate-y-0 group-hover/services:pointer-events-auto transition-all duration-200 z-50">
                <div className="bg-[#0A1E14] border border-[#C5A880]/30 rounded-2xl p-3 shadow-2xl backdrop-blur-2xl">
                  <div className="px-3 py-1.5 border-b border-white/10 mb-2 flex items-center justify-between">
                    <span className="text-[10px] uppercase tracking-widest text-[#C5A880] font-bold">
                      Arborist Divisions
                    </span>
                    <span className="text-[10px] text-white/40">6 Core</span>
                  </div>
                  <div className="space-y-0.5">
                    {siteConfig.services.map((service) => (
                      <a
                        key={service.id}
                        href="/#services"
                        className="flex items-center justify-between px-3 py-2 rounded-xl hover:bg-white/5 transition-colors group/item"
                      >
                        <div>
                          <div className="text-xs font-semibold text-white group-hover/item:text-[#DFCEB8] transition-colors leading-tight">
                            {service.title}
                          </div>
                          <div className="text-[10px] text-[#C5A880]/80 mt-0.5">
                            {service.tag}
                          </div>
                        </div>
                        <ArrowRight className="w-3.5 h-3.5 text-white/30 group-hover/item:text-[#DFCEB8] transition-transform group-hover/item:translate-x-1 shrink-0 ml-2" />
                      </a>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <a
              href="/#gallery"
              className="px-2.5 xl:px-3 py-1.5 text-xs xl:text-sm font-medium text-white/90 hover:text-white rounded-lg transition-colors whitespace-nowrap"
            >
              Gallery
            </a>

            <a
              href="/#before-after"
              className="px-2.5 xl:px-3 py-1.5 text-xs xl:text-sm font-medium text-white/90 hover:text-white rounded-lg transition-colors whitespace-nowrap"
            >
              Before &amp; After
            </a>

            <a
              href="/#service-areas"
              className="px-2.5 xl:px-3 py-1.5 text-xs xl:text-sm font-medium text-white/90 hover:text-white rounded-lg transition-colors whitespace-nowrap flex items-center gap-1"
            >
              <MapPin className="w-3.5 h-3.5 text-[#C5A880]" />
              <span>Areas</span>
            </a>

            <a
              href="/#testimonials"
              className="px-2.5 xl:px-3 py-1.5 text-xs xl:text-sm font-medium text-white/90 hover:text-white rounded-lg transition-colors whitespace-nowrap"
            >
              Reviews
            </a>

            <a
              href="/#contact"
              className="px-2.5 xl:px-3 py-1.5 text-xs xl:text-sm font-medium text-[#DFCEB8] hover:text-white rounded-lg transition-colors whitespace-nowrap font-bold"
            >
              Contact Us
            </a>

            <a
              href="/#faq"
              className="px-2.5 xl:px-3 py-1.5 text-xs xl:text-sm font-medium text-white/90 hover:text-white rounded-lg transition-colors whitespace-nowrap"
            >
              FAQ
            </a>
          </nav>

          {/* Right Action Group */}
          <div className="flex items-center gap-1.5 sm:gap-3 shrink-0">
            {/* Phone Button (Desktop XL - only when phone is set) */}
            {siteConfig.phone && (
              <a
                href={`tel:${siteConfig.phoneRaw}`}
                className="hidden xl:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-white transition-colors"
                aria-label={`Call ${siteConfig.phone}`}
              >
                <Phone className="w-3.5 h-3.5 text-[#C5A880] fill-current" />
                <div className="text-left">
                  <span className="text-[9px] uppercase font-bold text-[#C5A880] tracking-wider block leading-none">
                    24/7 Hotline
                  </span>
                  <span className="text-xs font-bold text-white whitespace-nowrap">
                    {siteConfig.phone}
                  </span>
                </div>
              </a>
            )}

            {/* Primary CTA Button */}
            <a
              href="#contact"
              className="inline-flex items-center justify-center gap-1.5 px-3 sm:px-4 py-2 rounded-xl bg-[#C5A880] hover:bg-[#DFCEB8] text-[#0A1E14] font-bold text-xs sm:text-sm tracking-wide shadow-md transition-all transform hover:scale-[1.02] whitespace-nowrap shrink-0"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#0A1E14]" />
              <span>Free Estimate</span>
            </a>

            {/* Mobile / Tablet Triggers */}
            <div className="flex items-center gap-1.5 lg:hidden shrink-0">
              {siteConfig.phone && (
                <a
                  href={`tel:${siteConfig.phoneRaw}`}
                  className="p-2 rounded-xl bg-[#0E2A1D] border border-[#C5A880]/40 text-[#C5A880] hover:bg-[#163E2B] transition-colors"
                  aria-label="Call Dispatch"
                  title="Call Dispatch"
                >
                  <Phone className="w-4 h-4 fill-current" />
                </a>
              )}

              <button
                type="button"
                onClick={() => setIsMobileMenuOpen(true)}
                aria-label="Open mobile menu"
                className="p-2 rounded-xl bg-[#0E2A1D] border border-[#C5A880]/40 text-white hover:bg-[#163E2B] transition-colors focus:outline-none shrink-0 shadow-md"
                title="Open Menu"
              >
                <Menu className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </header>

      <MobileMenu
        isOpen={isMobileMenuOpen}
        onClose={() => setIsMobileMenuOpen(false)}
      />
    </>
  );
}
