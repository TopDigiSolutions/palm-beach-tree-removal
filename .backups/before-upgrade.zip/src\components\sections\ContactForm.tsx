"use client";

import React, { useState, useRef, useEffect, ChangeEvent, FormEvent } from "react";
import { siteConfig } from "@/data/site";
import {
  Phone,
  Mail,
  MapPin,
  Clock,
  ShieldCheck,
  Award,
  Send,
  CheckCircle2,
  UploadCloud,
  Sparkles,
  MessageSquare,
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  X,
} from "lucide-react";

export default function ContactForm() {
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    city: "Palm Beach",
    service: "Hazardous Tree Removal",
    urgency: "Standard Inspection",
    date: "",
    time: "Morning (8AM - 12PM)",
    notes: "",
  });

  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [estimateRefId, setEstimateRefId] = useState("");

  // Custom Calendar State
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);
  const [calendarViewDate, setCalendarViewDate] = useState<Date>(new Date());
  const calendarRef = useRef<HTMLDivElement>(null);

  // Close calendar popover on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (calendarRef.current && !calendarRef.current.contains(event.target as Node)) {
        setIsCalendarOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleInputChange = (
    e: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setUploadedFile(e.target.files[0]);
    }
  };

  // Calendar Helper Functions
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const getDaysInMonth = (year: number, month: number) => {
    return new Date(year, month + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (year: number, month: number) => {
    return new Date(year, month, 1).getDay();
  };

  const handlePrevMonth = () => {
    setCalendarViewDate(
      new Date(calendarViewDate.getFullYear(), calendarViewDate.getMonth() - 1, 1)
    );
  };

  const handleNextMonth = () => {
    setCalendarViewDate(
      new Date(calendarViewDate.getFullYear(), calendarViewDate.getMonth() + 1, 1)
    );
  };

  const handleSelectDate = (day: number) => {
    const selected = new Date(
      calendarViewDate.getFullYear(),
      calendarViewDate.getMonth(),
      day
    );

    // Format as YYYY-MM-DD
    const monthStr = String(selected.getMonth() + 1).padStart(2, "0");
    const dayStr = String(selected.getDate()).padStart(2, "0");
    const dateFormatted = `${selected.getFullYear()}-${monthStr}-${dayStr}`;

    setFormData((prev) => ({ ...prev, date: dateFormatted }));
    setIsCalendarOpen(false);
  };

  const formatDisplayDate = (dateStr: string) => {
    if (!dateStr) return "Select Preferred Date";
    const [y, m, d] = dateStr.split("-").map(Number);
    const dateObj = new Date(y, m - 1, d);
    return dateObj.toLocaleDateString("en-US", {
      weekday: "short",
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  };

  const handleShortcutDate = (offsetDays: number) => {
    const d = new Date();
    d.setDate(d.getDate() + offsetDays);
    const monthStr = String(d.getMonth() + 1).padStart(2, "0");
    const dayStr = String(d.getDate()).padStart(2, "0");
    const dateFormatted = `${d.getFullYear()}-${monthStr}-${dayStr}`;
    setFormData((prev) => ({ ...prev, date: dateFormatted }));
    setIsCalendarOpen(false);
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    setTimeout(() => {
      const ref = `PBTR-${Math.floor(100000 + Math.random() * 900000)}`;
      setEstimateRefId(ref);
      setIsSubmitting(false);
      setIsSubmitted(true);
    }, 1200);
  };

  const handleReset = () => {
    setIsSubmitted(false);
    setFormData({
      name: "",
      phone: "",
      email: "",
      city: "Palm Beach",
      service: "Hazardous Tree Removal",
      urgency: "Standard Inspection",
      date: "",
      time: "Morning (8AM - 12PM)",
      notes: "",
    });
    setUploadedFile(null);
  };

  const whatsappMessage = encodeURIComponent(
    `Hello Palm Beach Tree Removal, I submitted an estimate request (Ref #${estimateRefId}) for ${formData.service} in ${formData.city}. My phone is ${formData.phone}.`
  );

  // Month & Year Labels
  const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];
  const currentYear = calendarViewDate.getFullYear();
  const currentMonth = calendarViewDate.getMonth();
  const daysInMonth = getDaysInMonth(currentYear, currentMonth);
  const firstDay = getFirstDayOfMonth(currentYear, currentMonth);

  return (
    <section
      id="contact"
      aria-label="Contact Us & Free Estimate Request"
      className="relative py-20 sm:py-28 lg:py-32 bg-[#06160E] text-white overflow-hidden"
    >
      {/* Ambient Decorative Background Effects */}
      <div className="absolute inset-0 pointer-events-none select-none overflow-hidden opacity-30">
        <div className="absolute -top-40 -left-40 w-96 h-96 rounded-full bg-[#1E5638] blur-[120px]" />
        <div className="absolute -bottom-40 -right-40 w-96 h-96 rounded-full bg-[#C5A880] blur-[140px] opacity-40" />
      </div>

      <div className="container-custom relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14 sm:mb-16">
          <div className="reveal-item inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#0E2A1D] border border-[#C5A880]/40 backdrop-blur-md mb-4 shadow-lg">
            <span className="w-2 h-2 rounded-full bg-[#C5A880] animate-pulse" />
            <span className="text-xs sm:text-sm font-semibold tracking-[0.2em] text-[#DFCEB8] uppercase">
              ESTATE INSPECTION &amp; 24/7 DISPATCH
            </span>
          </div>

          <h2 className="reveal-item delay-100 font-serif text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-white mb-4">
            Request Your Free On-Site Estimate
          </h2>

          <p className="reveal-item delay-200 text-sm sm:text-base md:text-lg text-white/80 leading-relaxed font-normal">
            Connect directly with an ISA Master Arborist. We provide prompt on-site assessments, guaranteed fixed pricing, zero lawn damage protocols, and $5M liability coverage.
          </p>
        </div>

        {/* Main Grid Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-start">
          
          {/* Left Column: Direct Contact Info & Authority Badges */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* 24/7 Dispatch Card */}
            <div className="p-6 sm:p-7 rounded-2xl bg-[#0E2A1D]/90 border border-[#C5A880]/30 shadow-2xl backdrop-blur-xl relative overflow-hidden group">
              <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                <Phone className="w-24 h-24 text-[#C5A880]" />
              </div>
              <div className="flex items-center gap-2 mb-3">
                <span className="relative flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
                </span>
                <span className="text-xs font-bold text-emerald-400 uppercase tracking-widest">
                  {siteConfig.phone ? "Live Dispatch Available Now" : "Online Dispatch Active 24/7"}
                </span>
              </div>
              <h3 className="text-xl font-bold text-white mb-1 font-serif">
                {siteConfig.phone ? "Direct Emergency Hotline" : "Rapid On-Site Assessment"}
              </h3>
              <p className="text-xs text-white/70 mb-4">
                {siteConfig.phone
                  ? "Rapid emergency response for fallen trees or storm damage across Palm Beach County."
                  : "Submit property details below. An ISA Certified Arborist reviews incoming estate scopes within hours."}
              </p>
              {siteConfig.phone ? (
                <a
                  href={`tel:${siteConfig.phoneRaw}`}
                  className="inline-flex items-center gap-3 px-5 py-3 rounded-xl bg-[#C5A880] hover:bg-[#DFCEB8] text-[#0A1E14] font-bold text-lg shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-0.5 w-full justify-center"
                >
                  <Phone className="w-5 h-5 fill-current text-[#0A1E14]" />
                  <span>Call {siteConfig.phone}</span>
                </a>
              ) : (
                <div className="flex items-center gap-2.5 px-4 py-2.5 rounded-xl bg-white/5 border border-[#C5A880]/30 text-xs text-[#DFCEB8]">
                  <Sparkles className="w-4 h-4 text-[#C5A880] shrink-0" />
                  <span>Priority scheduling applied to all online estimate submissions.</span>
                </div>
              )}
            </div>

            {/* Contact Details List */}
            <div className="p-6 sm:p-7 rounded-2xl bg-[#0E2A1D]/70 border border-white/10 shadow-xl backdrop-blur-md space-y-5">
              {siteConfig.email && (
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl bg-[#163E2B] border border-[#C5A880]/40 flex items-center justify-center text-[#C5A880] shrink-0 mt-0.5">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs text-[#DFCEB8] font-semibold uppercase tracking-wider">
                      Written Estimates Email
                    </div>
                    <a
                      href={`mailto:${siteConfig.email}`}
                      className="text-sm sm:text-base font-bold text-white hover:text-[#C5A880] transition-colors"
                    >
                      {siteConfig.email}
                    </a>
                  </div>
                </div>
              )}

              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-xl bg-[#163E2B] border border-[#C5A880]/40 flex items-center justify-center text-[#C5A880] shrink-0 mt-0.5">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs text-[#DFCEB8] font-semibold uppercase tracking-wider">
                    Palm Beach Office &amp; Operations Yard
                  </div>
                  <div className="text-xs sm:text-sm font-medium text-white/90 leading-tight">
                    {siteConfig.address.street}, {siteConfig.address.city}, FL {siteConfig.address.zip}
                  </div>
                  <div className="text-[11px] text-white/60 mt-0.5">
                    Dispatch Yard: {siteConfig.yardAddress.street}, {siteConfig.yardAddress.city}
                  </div>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-xl bg-[#163E2B] border border-[#C5A880]/40 flex items-center justify-center text-[#C5A880] shrink-0 mt-0.5">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs text-[#DFCEB8] font-semibold uppercase tracking-wider">
                    Service Hours
                  </div>
                  <div className="text-xs sm:text-sm text-white font-medium">
                    {siteConfig.hours.regular}
                  </div>
                  <div className="text-xs text-emerald-400 font-semibold mt-0.5">
                    {siteConfig.hours.emergency}
                  </div>
                </div>
              </div>
            </div>

            {/* Authority Trust Chips */}
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3.5 rounded-xl bg-white/[0.04] border border-white/10 flex items-center gap-3">
                <ShieldCheck className="w-6 h-6 text-[#C5A880] shrink-0" />
                <div>
                  <div className="text-[10px] text-white/60 uppercase font-bold">Protected</div>
                  <div className="text-xs font-bold text-white">$5M Insurance</div>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-white/[0.04] border border-white/10 flex items-center gap-3">
                <Award className="w-6 h-6 text-[#C5A880] shrink-0" />
                <div>
                  <div className="text-[10px] text-white/60 uppercase font-bold">Certified</div>
                  <div className="text-xs font-bold text-white">ISA Arborist</div>
                </div>
              </div>
            </div>

          </div>

          {/* Right Column: Interactive Form */}
          <div className="lg:col-span-7">
            <div className="p-6 sm:p-8 lg:p-10 rounded-3xl bg-[#0E2A1D]/90 border border-[#C5A880]/35 shadow-2xl backdrop-blur-2xl relative">
              
              {!isSubmitted ? (
                <form onSubmit={handleSubmit} className="space-y-6">
                  
                  {/* Form Headline */}
                  <div className="border-b border-white/10 pb-4 flex items-center justify-between">
                    <div>
                      <h3 className="text-xl sm:text-2xl font-bold font-serif text-white">
                        Estate Inspection Request
                      </h3>
                      <p className="text-xs text-white/70 mt-0.5">
                        Fill out details below for an instant callback and written proposal.
                      </p>
                    </div>
                    <Sparkles className="w-6 h-6 text-[#C5A880] hidden sm:block" />
                  </div>

                  {/* Personal Information */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-[#DFCEB8] mb-1.5">
                        Full Name *
                      </label>
                      <input
                        type="text"
                        name="name"
                        required
                        placeholder="e.g. Harrison Vance"
                        value={formData.name}
                        onChange={handleInputChange}
                        className="w-full px-4 py-3 rounded-xl bg-black/40 border border-white/15 text-white placeholder-white/40 focus:outline-none focus:border-[#C5A880] focus:ring-1 focus:ring-[#C5A880] text-sm transition-all"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-[#DFCEB8] mb-1.5">
                        Phone Number *
                      </label>
                      <input
                        type="tel"
                        name="phone"
                        required
                        placeholder="(561) 555-0199"
                        value={formData.phone}
                        onChange={handleInputChange}
                        className="w-full px-4 py-3 rounded-xl bg-black/40 border border-white/15 text-white placeholder-white/40 focus:outline-none focus:border-[#C5A880] focus:ring-1 focus:ring-[#C5A880] text-sm transition-all"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-[#DFCEB8] mb-1.5">
                        Email Address *
                      </label>
                      <input
                        type="email"
                        name="email"
                        required
                        placeholder="harrison@example.com"
                        value={formData.email}
                        onChange={handleInputChange}
                        className="w-full px-4 py-3 rounded-xl bg-black/40 border border-white/15 text-white placeholder-white/40 focus:outline-none focus:border-[#C5A880] focus:ring-1 focus:ring-[#C5A880] text-sm transition-all"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-[#DFCEB8] mb-1.5">
                        Property City / Area *
                      </label>
                      <select
                        name="city"
                        value={formData.city}
                        onChange={handleInputChange}
                        className="w-full px-4 py-3 rounded-xl bg-black/40 border border-white/15 text-white focus:outline-none focus:border-[#C5A880] focus:ring-1 focus:ring-[#C5A880] text-sm transition-all"
                      >
                        <option value="Palm Beach" className="bg-[#0E2A1D] text-white">Palm Beach Island</option>
                        <option value="Boca Raton" className="bg-[#0E2A1D] text-white">Boca Raton</option>
                        <option value="Wellington" className="bg-[#0E2A1D] text-white">Wellington Equestrian</option>
                        <option value="Delray Beach" className="bg-[#0E2A1D] text-white">Delray Beach</option>
                        <option value="Boynton Beach" className="bg-[#0E2A1D] text-white">Boynton Beach</option>
                        <option value="Highland Beach" className="bg-[#0E2A1D] text-white">Highland Beach</option>
                        <option value="West Palm Beach" className="bg-[#0E2A1D] text-white">West Palm Beach</option>
                        <option value="Lake Worth" className="bg-[#0E2A1D] text-white">Lake Worth</option>
                      </select>
                    </div>
                  </div>

                  {/* Service & Urgency Selection */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-[#DFCEB8] mb-1.5">
                        Primary Service Needed *
                      </label>
                      <select
                        name="service"
                        value={formData.service}
                        onChange={handleInputChange}
                        className="w-full px-4 py-3 rounded-xl bg-black/40 border border-white/15 text-white focus:outline-none focus:border-[#C5A880] focus:ring-1 focus:ring-[#C5A880] text-sm transition-all"
                      >
                        <option value="Hazardous Tree Removal" className="bg-[#0E2A1D]">Hazardous Crane Tree Removal</option>
                        <option value="Tree Trimming & Pruning" className="bg-[#0E2A1D]">Tree Trimming & Pruning</option>
                        <option value="Emergency Storm Response" className="bg-[#0E2A1D]">24/7 Emergency Storm Clearance</option>
                        <option value="Palm Sculpting" className="bg-[#0E2A1D]">Palm Sculpting & Shaping</option>
                        <option value="Stump Grinding" className="bg-[#0E2A1D]">Sub-Grade Stump Grinding</option>
                        <option value="Whole Estate Clearing" className="bg-[#0E2A1D]">Whole Estate Canopy Clearing</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-[#DFCEB8] mb-1.5">
                        Response Urgency *
                      </label>
                      <select
                        name="urgency"
                        value={formData.urgency}
                        onChange={handleInputChange}
                        className="w-full px-4 py-3 rounded-xl bg-black/40 border border-white/15 text-white focus:outline-none focus:border-[#C5A880] focus:ring-1 focus:ring-[#C5A880] text-sm transition-all"
                      >
                        <option value="Emergency Response (Immediate)" className="bg-[#0E2A1D]">Emergency Response (Immediate 24/7)</option>
                        <option value="Standard Inspection (24-48 Hours)" className="bg-[#0E2A1D]">Next 24-48 Hours</option>
                        <option value="Flexible Inspection Date" className="bg-[#0E2A1D]">Flexible Inspection Date</option>
                      </select>
                    </div>
                  </div>

                  {/* Date & Time Preferences with Custom Styled Calendar Picker */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    
                    {/* CUSTOM THEME CALENDAR PICKER */}
                    <div className="relative" ref={calendarRef}>
                      <label className="block text-xs font-bold uppercase tracking-wider text-[#DFCEB8] mb-1.5">
                        Preferred Inspection Date
                      </label>

                      {/* Trigger Input Button */}
                      <button
                        type="button"
                        onClick={() => setIsCalendarOpen(!isCalendarOpen)}
                        className="w-full px-4 py-3 rounded-xl bg-black/40 border border-white/15 hover:border-[#C5A880]/60 text-left text-white focus:outline-none focus:border-[#C5A880] focus:ring-1 focus:ring-[#C5A880] text-sm transition-all flex items-center justify-between group cursor-pointer"
                      >
                        <div className="flex items-center gap-2.5 truncate">
                          <CalendarIcon className="w-4 h-4 text-[#C5A880] shrink-0" />
                          <span className={formData.date ? "font-semibold text-white" : "text-white/40"}>
                            {formatDisplayDate(formData.date)}
                          </span>
                        </div>
                        <span className="text-[11px] font-bold text-[#C5A880] group-hover:underline ml-2 shrink-0">
                          {isCalendarOpen ? "Close" : "Pick Date"}
                        </span>
                      </button>

                      {/* POPUP CALENDAR DROPDOWN */}
                      {isCalendarOpen && (
                        <div className="absolute top-full left-0 mt-2 z-50 w-72 sm:w-80 p-4 rounded-2xl bg-[#0A1E14] border-2 border-[#C5A880]/50 shadow-[0_20px_50px_rgba(0,0,0,0.8)] backdrop-blur-2xl animate-fadeIn">
                          
                          {/* Calendar Month/Year Header */}
                          <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-3">
                            <button
                              type="button"
                              onClick={handlePrevMonth}
                              className="p-1.5 rounded-lg hover:bg-white/10 text-[#C5A880] transition-colors"
                              aria-label="Previous Month"
                            >
                              <ChevronLeft className="w-5 h-5" />
                            </button>

                            <div className="text-sm font-bold font-serif text-[#DFCEB8]">
                              {monthNames[currentMonth]} {currentYear}
                            </div>

                            <button
                              type="button"
                              onClick={handleNextMonth}
                              className="p-1.5 rounded-lg hover:bg-white/10 text-[#C5A880] transition-colors"
                              aria-label="Next Month"
                            >
                              <ChevronRight className="w-5 h-5" />
                            </button>
                          </div>

                          {/* Day Headers (Sun - Sat) */}
                          <div className="grid grid-cols-7 gap-1 text-center mb-2">
                            {["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"].map((dayName, idx) => (
                              <div key={idx} className="text-[11px] font-bold text-[#DFCEB8]/70 uppercase">
                                {dayName}
                              </div>
                            ))}
                          </div>

                          {/* Days Grid */}
                          <div className="grid grid-cols-7 gap-1 text-center">
                            {/* Empty offset cells */}
                            {Array.from({ length: firstDay }).map((_, idx) => (
                              <div key={`empty-${idx}`} className="w-8 h-8" />
                            ))}

                            {/* Month Days */}
                            {Array.from({ length: daysInMonth }).map((_, idx) => {
                              const dayNumber = idx + 1;
                              const cellDate = new Date(currentYear, currentMonth, dayNumber);
                              cellDate.setHours(0, 0, 0, 0);

                              const isPast = cellDate < today;
                              const isToday = cellDate.getTime() === today.getTime();

                              // Check if selected
                              const monthStr = String(currentMonth + 1).padStart(2, "0");
                              const dayStr = String(dayNumber).padStart(2, "0");
                              const formattedCellDate = `${currentYear}-${monthStr}-${dayStr}`;
                              const isSelected = formData.date === formattedCellDate;

                              return (
                                <button
                                  key={dayNumber}
                                  type="button"
                                  disabled={isPast}
                                  onClick={() => handleSelectDate(dayNumber)}
                                  className={`w-8 h-8 sm:w-9 sm:h-9 rounded-lg text-xs font-semibold flex items-center justify-center transition-all cursor-pointer mx-auto ${
                                    isSelected
                                      ? "bg-[#C5A880] text-[#0A1E14] font-extrabold shadow-lg scale-110 ring-2 ring-white/50"
                                      : isPast
                                      ? "text-white/20 cursor-not-allowed"
                                      : isToday
                                      ? "border border-[#C5A880] text-[#C5A880] hover:bg-[#163E2B]"
                                      : "text-white hover:bg-[#163E2B] hover:text-[#C5A880]"
                                  }`}
                                >
                                  {dayNumber}
                                </button>
                              );
                            })}
                          </div>

                          {/* Quick Shortcut Buttons */}
                          <div className="pt-3 mt-3 border-t border-white/10 flex items-center justify-between gap-1 text-[11px]">
                            <button
                              type="button"
                              onClick={() => handleShortcutDate(0)}
                              className="px-2.5 py-1 rounded-md bg-white/5 hover:bg-white/15 text-[#DFCEB8] transition-colors"
                            >
                              Today
                            </button>
                            <button
                              type="button"
                              onClick={() => handleShortcutDate(1)}
                              className="px-2.5 py-1 rounded-md bg-white/5 hover:bg-white/15 text-[#DFCEB8] transition-colors"
                            >
                              Tomorrow
                            </button>
                            <button
                              type="button"
                              onClick={() => handleShortcutDate(3)}
                              className="px-2.5 py-1 rounded-md bg-white/5 hover:bg-white/15 text-[#DFCEB8] transition-colors"
                            >
                              +3 Days
                            </button>
                          </div>
                        </div>
                      )}
                    </div>

                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-[#DFCEB8] mb-1.5">
                        Preferred Time Slot
                      </label>
                      <select
                        name="time"
                        value={formData.time}
                        onChange={handleInputChange}
                        className="w-full px-4 py-3 rounded-xl bg-black/40 border border-white/15 text-white focus:outline-none focus:border-[#C5A880] focus:ring-1 focus:ring-[#C5A880] text-sm transition-all"
                      >
                        <option value="Morning (8AM - 12PM)" className="bg-[#0E2A1D]">Morning (8:00 AM - 12:00 PM)</option>
                        <option value="Afternoon (12PM - 4PM)" className="bg-[#0E2A1D]">Afternoon (12:00 PM - 4:00 PM)</option>
                        <option value="Late Afternoon (4PM - 6PM)" className="bg-[#0E2A1D]">Late Afternoon (4:00 PM - 6:00 PM)</option>
                      </select>
                    </div>
                  </div>

                  {/* Photo Upload Simulator */}
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-[#DFCEB8] mb-1.5">
                      Upload Tree Photos / Site Layout (Optional)
                    </label>
                    <div className="relative border-2 border-dashed border-white/20 hover:border-[#C5A880]/60 rounded-2xl p-4 text-center bg-black/20 transition-colors">
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleFileChange}
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                      />
                      <div className="flex flex-col items-center justify-center gap-1.5">
                        <UploadCloud className="w-7 h-7 text-[#C5A880]" />
                        {uploadedFile ? (
                          <div className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
                            <CheckCircle2 className="w-4 h-4" />
                            <span>Attached: {uploadedFile.name}</span>
                          </div>
                        ) : (
                          <>
                            <span className="text-xs font-semibold text-white">
                              Click or Drag &amp; Drop photos of the tree
                            </span>
                            <span className="text-[11px] text-white/50">
                              PNG, JPG up to 15MB (helps our arborist pre-analyze crane setup)
                            </span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Special Notes */}
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-[#DFCEB8] mb-1.5">
                      Project Notes / Gate Access Code / Instructions
                    </label>
                    <textarea
                      name="notes"
                      rows={3}
                      placeholder="Specify tree species, proximity to structures/pools, or gate code for property entry..."
                      value={formData.notes}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 rounded-xl bg-black/40 border border-white/15 text-white placeholder-white/40 focus:outline-none focus:border-[#C5A880] focus:ring-1 focus:ring-[#C5A880] text-sm transition-all"
                    />
                  </div>

                  {/* Submit Button */}
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-4 px-8 rounded-xl bg-[#C5A880] hover:bg-[#DFCEB8] text-[#0A1E14] font-extrabold text-lg shadow-xl hover:shadow-2xl transition-all transform hover:-translate-y-0.5 flex items-center justify-center gap-3 cursor-pointer group disabled:opacity-50"
                  >
                    {isSubmitting ? (
                      <span className="flex items-center gap-2">
                        <span className="w-5 h-5 border-2 border-[#0A1E14] border-t-transparent rounded-full animate-spin" />
                        <span>Transmitting Request...</span>
                      </span>
                    ) : (
                      <>
                        <Send className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                        <span>Submit Free Estimate Request</span>
                      </>
                    )}
                  </button>

                  <p className="text-[11px] text-center text-white/50">
                    🔒 Your information is confidential. We respect your estate privacy and never share contact details.
                  </p>
                </form>
              ) : (
                /* Submission Confirmation State */
                <div className="py-8 px-4 text-center space-y-6 animate-fadeIn">
                  <div className="w-16 h-16 rounded-full bg-emerald-500/20 border border-emerald-400 text-emerald-400 flex items-center justify-center mx-auto">
                    <CheckCircle2 className="w-10 h-10" />
                  </div>

                  <div>
                    <span className="text-xs font-extrabold text-[#C5A880] uppercase tracking-widest block mb-1">
                      ESTIMATE REQUEST CONFIRMED
                    </span>
                    <h3 className="text-2xl sm:text-3xl font-bold font-serif text-white mb-2">
                      Thank You, {formData.name || "Valued Estate Owner"}!
                    </h3>
                    <p className="text-sm text-white/80 max-w-md mx-auto leading-relaxed">
                      Your estimate request has been logged under Reference ID:{" "}
                      <strong className="text-[#C5A880] font-mono text-base">{estimateRefId}</strong>.
                      An ISA Certified Arborist will review your property details and contact you shortly.
                    </p>
                  </div>

                  {/* Summary Card */}
                  <div className="p-4 rounded-2xl bg-black/40 border border-white/10 text-left text-xs space-y-2 max-w-md mx-auto">
                    <div className="flex justify-between border-b border-white/10 pb-1.5">
                      <span className="text-white/60">Service:</span>
                      <span className="font-bold text-white">{formData.service}</span>
                    </div>
                    <div className="flex justify-between border-b border-white/10 pb-1.5">
                      <span className="text-white/60">Property Area:</span>
                      <span className="font-bold text-white">{formData.city}</span>
                    </div>
                    <div className="flex justify-between border-b border-white/10 pb-1.5">
                      <span className="text-white/60">Inspection Date:</span>
                      <span className="font-bold text-[#DFCEB8]">{formatDisplayDate(formData.date)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-white/60">Urgency:</span>
                      <span className="font-bold text-emerald-400">{formData.urgency}</span>
                    </div>
                  </div>

                  {/* Instant Action Options */}
                  <div className="flex flex-col sm:flex-row gap-3 justify-center pt-2">
                    {siteConfig.phone && (
                      <a
                        href={`tel:${siteConfig.phoneRaw}`}
                        className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-[#C5A880] hover:bg-[#DFCEB8] text-[#0A1E14] font-bold text-sm shadow-lg"
                      >
                        <Phone className="w-4 h-4 fill-current" />
                        <span>Call Dispatch Directly Now</span>
                      </a>
                    )}

                    {siteConfig.phoneRaw && (
                      <a
                        href={`https://wa.me/${siteConfig.phoneRaw.replace("+", "")}?text=${whatsappMessage}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-[#1E5638] hover:bg-[#2D754E] border border-[#C5A880]/50 text-white font-bold text-sm shadow-lg"
                      >
                        <MessageSquare className="w-4 h-4" />
                        <span>Send Details via WhatsApp</span>
                      </a>
                    )}

                    {!siteConfig.phone && (
                      <a
                        href="#testimonials"
                        className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-[#C5A880] hover:bg-[#DFCEB8] text-[#0A1E14] font-bold text-sm shadow-lg"
                      >
                        <span>View Verified Client Reviews</span>
                      </a>
                    )}
                  </div>

                  <button
                    onClick={handleReset}
                    className="text-xs text-white/50 hover:text-white underline transition-colors pt-4 block mx-auto cursor-pointer"
                  >
                    Submit another property request
                  </button>
                </div>
              )}

            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
